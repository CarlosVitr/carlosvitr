# Brand
---

<p align="center">
<img align="center" src="Logos/Logo-transparent.png">
</p>

### Reduce your time with our tools, here we are here to make your life easier.
#### Turbocharge your professional front/back end: 

- Check vacancies, surveys, etc. 
- Statistics. 
- And much more. 

sign up <a>Tradespot.ga</a>

---

# License

**Brand©** <a href="http://tradespot.ga">TradeSpot</a>, Launched under the [License MIT](https://github.com/Tradespot/brand/blob/main/LICENSE). Authored and maintained by Carlos Vítor with the help of <a href="https://github.com/tradespot/brand/graphs/contributors">collaborators</a>.
> Github:<a href="https://github.com/Tradespot">@TradeSpot</a> • Twitter:<a href="https://twitter.com/TSpothq">@TSpothq</a>.
<!-- • LinkedIn:<a href="https://linkedin.com/in/"></a>
Username: TSpothq
PassWord: T®@|}€s¶0t0305
-->
